package model.entity;

public class Login {

	public String User_id;
	public String User_Pass;

	public Login() {	}

	public String getUser_id() {return User_id;}
	public void setUser_id(String user_id) {User_id = user_id;}
	public String getUser_Pass() {return User_Pass;}
	public void setUser_Pass(String user_Pass) {User_Pass = user_Pass;}

}
